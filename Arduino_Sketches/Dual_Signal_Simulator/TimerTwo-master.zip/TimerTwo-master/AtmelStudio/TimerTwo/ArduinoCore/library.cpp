/*
 * ArduinoCore.cpp
 *
 * Created: 24.11.2020 20:49:10
 * Author : aburn
 */ 

#include <avr/io.h>


/* Replace with your library code */
int myfunc(void)
{
	return 0;
}

